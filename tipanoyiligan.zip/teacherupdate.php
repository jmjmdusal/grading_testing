<?php
  include('connection.php');

  $teacherID= $_GET['id'];

  //echo $teacherID;
  if (isset($_POST['save'])){
    $teacher_lastname = $_POST['teacher_lastname'];
    $teacher_firstname = $_POST['teacher_firstname'];
    $teacher_middlename = $_POST['teacher_middlename'];
    $teacher_address = $_POST['teacher_address'];
    $teacher_contact_number = $_POST['teacher_contact_number'];
    $teacher_username = $_POST['teacher_username'];
    $teacher_password = $_POST['teacher_password'];
    
    


    $sql2 = "UPDATE teacher SET teacher_lastname='$teacher_lastname', teacher_firstname='$teacher_firstname', teacher_middlename='$teacher_middlename', teacher_address='$teacher_address', teacher_contact_number='$teacher_contact_number', teacher_username='$teacher_username', teacher_password='$teacher_password'  WHERE teacher_id = $teacherID";



    $sql2 = mysqli_query($db,$sql2);
    header("Location:teacherdetails.php");


  }
  else{
    echo "<script>alert('Are you sure you want to update this data??')</script>";
      
      
  }
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
<title>Edit</title>

</head>
<body>
  <div class="header">
            <h2>Edit Teacher</h2>
    </div>
  <style>
    
    body{
      background-image: url("school.jpg");
          background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
          background-position: center center;
            font-family: cursive;
            cursor: pointer;     

    } 
    body:after{
      content: "";
      background: url("cover1.jpg");
      opacity: 1.0;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      position: absolute;
      z-index: -5;
      
    }

    form{
    width: 30%;
    margin: 0px auto;
    font-size: 15px;
    font-weight: bold;
    padding: 20px;
    border: 1px solid #000;
    background: white;
    border-radius: 0px 0px 10px 10px;
}

.input-group{
    margin: 10px 0px 10px 0px;
}
.input-group label{
    display: block;
    text-align: left;
    margin: 3px;
}
.input-group input{
    height: 30px;
    width: 93%;
    padding: 5px 10px;
    font-size: 16px;
    border-radius: 6px;
    border: 2px solid gray;
}
.btn{
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #3bd478;
    border: none;
    border-radius: 5px;
}

.header {
    width: 30%;
    margin: 50px auto 0px;
    color: white;
    background: url('images/cover1.jpg');
    /*background: #6174ff;*/
    text-align: center;
    border: 1px solid #000;
    border-bottom: none;
    border-radius: 10px 10px 0px 0px;
    padding: 20px;

}
.header a{
    text-decoration: none;
    color: black;
    font-family: cursive;
}

  </style>


  <?php
    $sql = "SELECT * FROM teacher WHERE teacher_id = $teacherID";
    
    $query = mysqli_query($db,$sql);
    $data = mysqli_fetch_assoc($query);
  

    
?>



<form action="#" method="post" style="text-align: center; font-family: cursive; ">

<div class="input-group">
<label>LASTNAME</label>
<input type="text" name="teacher_lastname" value="<?php echo $data['teacher_lastname']; ?>" ><br></br>
</div>

<div class="input-group">
<label>FIRSTNAME</label>
<input type="text" name="teacher_firstname" value="<?php echo $data['teacher_firstname']; ?>" ><br></br>
</div>

<div class="input-group">
<label>MIDDLENAME</label>
<input type="text" name="teacher_middlename" value="<?php echo $data['teacher_middlename']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>ADDRESS</label>
<input type="text" name="teacher_address" value="<?php echo $data['teacher_address']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>CONTACT #</label> 
<input type="number" name="teacher_contact_number" value="<?php echo $data['teacher_contact_number']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>USERNAME</label>
<input type="text" name="teacher_username" value="<?php echo $data['teacher_username']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>PASSWORD</label>
<input type="text" name="teacher_password" value="<?php echo $data['teacher_password']; ?>" ><br/><br/>
</div>

<input type="submit" name="save" value="Submit"/>
<a href="teacherdetails.php" style="text-decoration: none;"><button type="button">Back</a></td></td>


 

</form>
</body>
</html>
