<?php
include('connection.php');

$id=$_GET['id'];

$sql ="delete from parents where parent_id=$id";
$query = mysqli_query($db, $sql);
if($query){
			echo "<script> alert('Information deleted successfully!');</script>";
			echo "<script>window.location='parentdetails.php';</script>";
	}
	else{
		echo "<script>alert('Oops! Error Occured!!');</script>";
		echo "<script>window.location='parentdetails.php';</script>";
	}

	
	
	


?>