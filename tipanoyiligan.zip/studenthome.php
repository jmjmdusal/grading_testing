<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>

	<title>Student Dashboard</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
	
	<style type="text/css">

		body{
			background-image: url("school.jpg");
         	background-repeat: no-repeat;
          	background-attachment: fixed;
          	background-size: 100%;
         	background-position: center;
          	font-family: cursive;
          	cursor: pointer;
		}
		body:after{
			content: "";
			background: url("logo.png");
			opacity: 1.0;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
			position: absolute;
			z-index: -5;

		}

		h1{
			text-align:center;
   			color: #000;
   			font-family: cursive;
   			font-size: 50px;
   			margin-top: 120px;
		}

		a:link,a:visited{
			display: block;
			font-weight: bold;
			color: white;
			text-transform: uppercase;
			text-decoration: none;
		}
		ul {
		    list-style-type: none;
		    margin-top: 60px;
		    margin-left: 60px;
		    margin-right: 60px;
		    padding: 10px 5px;
		    overflow: hidden;
		    background-color: #2b864b;
		    top: 0;
		    border-radius: 10px;
		}

		li {
		    float: left;
		}

		li a {
		    display: block;
		    color: #000;
		    text-align: center;
		   	margin-left: 90px;
		   	margin-right: 150px;
		   	padding:5px 90px;
		   	text-decoration: none;
		    font-size: 20px;
		    font-weight: bold;
		}
		li a:hover:not(.active) {
		    background-color: 	#0d54f5;
		}

		li a:hover {
		    background-color:	#0d54f5;
		   	border-radius: 4px;
		}
		li a.active{
			 background-color: 	#0d54f5;
			 border-radius: 4px;
		}




	</style>
</head>
<body>

	<h1 style="color: white;"> Tipanoy Elementary School</h1><br>

	<p style="text-align: center;font-size: 30px; font-weight: bolder;background-color: #2b864b;padding: 5px 5px; color: white; margin-left: 500px; margin-right: 500px;border-radius: 15px; "><i style="margin-right: 5px;" class="fas fa-users"></i>STUDENT</p>

	<nav>
		<ul>
				<li><a href="viewGrades3.php"><i style="margin-right: 5px;" class="fas fa-eye"></i>VIEW STUDENT GRADES</a></li>
				<li><a href="index.php"><i style="margin-right: 5px;" class="fas fa-sign-out-alt"></i>LOGOUT</a></li>

		</ul>
	</nav>


</body>
</html>
