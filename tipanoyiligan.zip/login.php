
<?php 
session_start();
include('connection.php');


      if(isset($_POST['login'])){

      $username = $_POST['username'];
      $password = $_POST['password'];


      $query11 = "SELECT * FROM admin WHERE admin_username= '$username' AND admin_password = '$password'";
      $result1 = mysqli_query($db, $query11);

      $query21 = "SELECT * FROM parents WHERE parent_username = '$username' AND parent_password = '$password'";
      $res = mysqli_query($db, $query21);

      $query31 = "SELECT * FROM student WHERE student_username ='$username' AND student_password ='$password'";
      $result1234 = mysqli_query($db, $query31);

      $query41 = "SELECT * FROM teacher WHERE teacher_username ='$username' AND teacher_password ='$password'";
      $result123 = mysqli_query($db, $query41);


      if (($result1)) {

        if(mysqli_num_rows($result1)){

        header('location: adminhome.php');


        }
      }

      if(!empty($result1234)){
      if(mysqli_num_rows($result1234)){
        $parents = mysqli_fetch_assoc($result1234);

        header('location:studenthome.php');

      }
    }

      if(!empty($result12)){
      if(mysqli_num_rows($result12)){
        $parents = mysqli_fetch_assoc($result12);

        header('location:homepage.php');

      }
    }

      if (($result123)) {
        if(mysqli_num_rows($result123)) {
        $rows11 = mysqli_fetch_assoc($result123);
        $teacher = 'teacherhome.php';
        $_SESSION['teacherID'] = $rows11['teacherID'];

        header('location: teacherhome.php');
      }

      }
      // $password =md5($password);
      if (($res)) {
        if(mysqli_num_rows($res)) {
        $rows11 = mysqli_fetch_assoc($res);
        $parents = 'parenthome.php';
        $_SESSION['parentID'] = $rows11['parentID'];

        header('location: parenthome.php');
      }

        echo "<script>alert('Login Success!');</script>";
        echo "<script>window.open('parenthome.php','_self');</script>";
      }
  }

 ?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
  <title>Login</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
</head>
<body>
  <header>

    <nav>
      <center><div id="one" class="homehome" >
        <center>
            <img src="icon1.png" id="id1"><br><br>

            <div class="nav-login">
                <form method="post" >
                    <input type="text" name="username" placeholder="Username"><br>
                    <input type="password" name="password" placeholder="Password"><br>
                  <button class="btn" type="submit" name="login"><i class="fas fa-sign-in-alt"></i>Login</button>
                </form>

                <a id="click" href="registrationform.php"
                    style="text-decoration: none;  "><button style="font-family: cursive; padding-left: 10px; padding-right: 10px; border-radius: 5px; background-color: #3bd478;"><i class="fas fa-user-plus"></i>Sign up</button></a>
                   <a href="index.php"> <button style="font-family: cursive; padding-left: 10px; padding-right: 10px; border-radius: 5px; background-color: #3bd478;"><i class="fas fa-backspace"></i>Back</button></a>
            </div>
        </center>
      <center></div>


    </nav>
  </header>


  <style>
        body{
          background-image: url("school.jpg");
          background-repeat: no-repeat;
          background-attachment: fixed;
          background-size: 1500px 1500px;
          background-position: center;
          font-family: cursive;
          cursor: pointer;

        }

        #one{
          width: 400px;
          height: 500px;
          border-style: solid;
          border-color: #000;
          background-color: #9c9cab;
          margin: 5% ;
          border-radius: 15%;
          background-position: center;
        }
        div.nav-login{
          margin-top: 5%;

        }
        #id1{
          margin-top: 5%;
          height: 50%;
          width: 50%;
        }
        input{
          margin-bottom: 20px;
          border-radius: 5px;
          width: 55%;
          border: 1px solid;
          height: 25px;
          font-family: cursive;
        }
        .btn {
          background-color: #3bd478;
          border: none;
          color: black;
          padding: 5px 32px;
          text-align: center;
          font-size: 16px;
          margin: 4px 2px;
          opacity: 1;
          transition: 0.3s;
          border-radius: 7px;
          margin-bottom: 10px;
          font-family: cursive;
        }
        .btn:hover {opacity: 0.6}

        #click {
          background-color: #fff;
          border: none;
          color: #000;

          text-align: center;
          font-size: 12px;
          margin: 4px 2px;
          opacity: 1;
          transition: 0.3s;
          border-radius: 6px;
        }

        #click:hover {opacity: 0.6}

     </style>

</body>
</html>
