
<?php
// session_start();
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "queen";

// Create connection
$db = new mysqli($hostname, $username, $password, $dbname);

// Check connection
if ($db->connect_error){
    die("Connection failed: " . $db->connect_error);
}



?>


