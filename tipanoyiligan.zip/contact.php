<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>

	<title>Tipanoy Elementary School</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">		
	<style>
		body {
			background-image: url("school.jpg");
			background-attachment: fixed;
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center center;
			font-family: cursive;
			cursor: pointer;
			}

		body:after{
			content: "";
			opacity: 1.10;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
			position: absolute;
			z-index: -5;

			}
		header {
  			background-color: #666;
  			padding: 5%;
  			text-align: center;
  			font-size: 150%;
  			color: white;
  			width: 40%;
  			margin-top: 10%;
			}
			ul {
		    list-style-type: none;
		    margin-left: 50px;
		    padding: 0px 0px 12px;
		    overflow: hidden;
		    bottom: 0;
		    width: 100%;
		    font-size: 15px;
		}

		li {
		    float: left;
		    margin-left: 5px;
		}

		li a {
		    display: block;
		    color: white;
		    text-align: center;
		    padding: 6px 15px 6px 15px;
		    text-decoration: none;
		    background-color: grey;
		}

		li a:hover:not(.active) {
			background-color: #ff1414;
		    border-radius: 8px;
		}
		#l{
			margin-left: 2%;
			margin-top: 30px;
			text-align-last: center;
			border: 3px solid black;
			background-color: #2b864b;
			font-size: 200%;
			border-radius: 10px;
			padding: 5px 0px 5px 20px;
			word-break: keep-all;
			width: 650px;
			height: 140px;
		}
	</style>
	</head>
	<body>
		<center>
				<div id="l">
					<p style="color: white;"><i style="margin-right: 5px;" class="fas fa-phone"></i>Contact Us.<br>221-4789</p>
				</div>
		</center>
	</body>
	<ul>
                <center><li><a href="index.php" style="margin-left: 350px; border: 1px solid #000;"><i style="margin-right: 5px;" class="fas fa-backspace"></i>BACK</a></li></center>
        



        </ul>
</html>