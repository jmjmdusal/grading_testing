<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>

	<title>Tipanoy Elementary School</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">		
	<style>
		body {
			background-image: url("school.jpg");
			background-attachment: fixed;
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center center;
			font-family: cursive;
			cursor: pointer;
		}

		body:after{
			content: "";
			opacity: 1.10;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
			position: absolute;
			z-index: -5;

		}
		.container img{
			margin-top: -250px;
			margin-bottom: -30px;
			margin-left: 40px;
			max-height: 400px;
			max-width: 400px;
		}
		.container p{
			text-align: center;
			font-size: 32px;
			margin-left: 390px;
			margin-right: 200px;
			margin-top: 50px;
			font-weight: bolder;
			text-decoration: none;
		}
	  	.container {
		    width: 92%;
		    margin: 0 auto;
		    background: rgba(221, 222, 226, .4);
		    background: url('images/chalkboard.jpg');
		    background-attachment: fixed;
			background-repeat: no-repeat;
			background-size: 100%;
			background-position: center bottom;
			font-family: cursive;
			cursor: pointer;
		    /*background-color: #1fb7ff;*/
		    padding: 30px;
		    text-decoration: none;
		}

		body {margin:0;}

		ul {
		    list-style-type: none;
		    margin-left: 50px;
		    padding: 0px 0px 12px;
		    overflow: hidden;
		    bottom: 0;
		    width: 100%;
		    font-size: 15px;
		}

		li {
		    float: left;
		    margin-left: 5px;
		}

		li a {
		    display: block;
		    color: black;
		    text-align: center;
		    padding: 6px 15px 6px 15px;
		    text-decoration: none;
		}

		li a:hover:not(.active) {
			background-color: #ff1414;
		    border-radius: 8px;
		}

		.active {
		    background-color: #3bd478;
		    border-radius: 8px;
		}

		.mySlides {
			display:block;

		}
		#left{
			text-align: center;
			/*background-color: #fff;*/
			float: left;
			margin-left: 630px;
			font-size: 22px;
			font-weight: bold;
			font-weight: bolder;
		}

		#l{
			margin-left: 350px;
			margin-top: 30px;
			text-align-last: center;
			border: 3px solid black;
			background-color: #2b864b;
			font-size: 20px;
			border-radius: 10px;
			padding: 5px 0px 5px 20px;
			word-break: keep-all;
			width: 650px;
			height: 140px;
		}

		.footer p{
			text-align: center;
			padding: 15px 15px;
			margin-bottom: 1px;
			margin-top: 13%;
			color: #000;
			font-weight: bold;
		}
		#pi{
		  font-size: 20px;
		  

		}


	</style>

	</head>
	<body>

	<div class="container">
		<p style="color: white;">TIPANOY ELEM. SCHOOL ONLINE GRADING AND INQUIRY SYSTEM</p>
		<img src="icon1.png" title="Tipanoy Elementary School"></a>
	 	<ul style="font-size: 25px; font-family: cursive;">
		  <b><li><a class="active" href="login.php"><i style="margin-right: 5px;" class="fas fa-sign-in-alt"></i>Login</li></a>
		  	<b><li><a class="active" href="contact.php"><i style="margin-right: 5px;" class="fas fa-phone"></i>Contact Us</li></a>
		</ul>
		<hr>
	 </div>

			<div class="w3-content w3-section" style="width: 1300px; height: 700px; padding-left: 25px; padding-right: 25px;">

			  <img class="mySlides" src="tipanoy2.jpg" style="width:100%;height: 100%">
			  <img class="mySlides" src="tipanoy1.jpg" style="width:100%;height: 100%">
			  <img class="mySlides" src="tipanoy3.jpg" style="width:100%;height: 100%">
			  <img class="mySlides" src="tipanoy4.jpg" style="width:100%;height: 100%">

			</div>
		<script>
			var myIndex = 0;
			carousel();

			function carousel() {
			    var i;
			    var x = document.getElementsByClassName("mySlides");
			    for (i = 0; i < x.length; i++) {
			       x[i].style.display = "none";
			    }
			    myIndex++;
			    if (myIndex > x.length) {myIndex = 1}
			    x[myIndex-1].style.display = "block";
			    setTimeout(carousel, 2500); // Change image every 2 seconds
			}
		</script>

				<center><h1 style="color:white; margin-top: 13%; padding: 10px 30px 20px 30px; border-radius: 70px; text-decoration: none;">About Us</h1></center>

		<div id="left">
			<p style="color: white;">MISSION</p>
		</div>
		<br><br>
				<div id="l">
					<p style="color: white;">Through the inspiration of Mary, Tipanoy Elementary School, we commit ourselves to promote quality education founded on Christian and family Values to develop responsible, self-reliant, spiritually and socially matured citizens.</p>
				</div>


		<div id="left">
			<p style="color: white;">VISION</p>
		</div>
		<br><br>
				<div id="l">
					<p style="color: white;">A Christian Marian institution that will serve the community through the family renewal and quality education.</p>
				</div>


		<div class="footer">
			<div id="pi">
				<p style="color: white;">Copyright © 2018 - Tipanoy Elementary School </p>
			</div>
		</div>


</body>
</html>
