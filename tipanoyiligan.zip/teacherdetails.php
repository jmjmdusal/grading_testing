<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
    <title>Teacher Details</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" type="text/css" href="css/teacherdetails.css">
</head>
            <center><h1 style="color: white;">Teacher Details</h1></center>

        
        <hr>
            <table class="tab3" style="font-family: cursive; ">
                <thead> 
        <!-- <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;">ID</th> -->
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-user-tie"></i>TEACHER LASTNAME</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-user-tie"></i>TEACHER FIRSTNAME</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-user-tie"></i>TEACHER MIDDLENAME</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-address-book"></i>TEACHER ADDRESS</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-phone"></i>CONTACT #</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;">ACTIONS</th>

                </thead>
                <tbody bgcolor="#C0C0C0" style="text-align: center;">
                    <!-- <button class="logout" type="button"><a href="home.php">Log Out</a></button> -->
                    <?php
                        include('connection.php');

                        $sql = "Select * FROM teacher";
                        

                        $query = mysqli_query($db,$sql);
                        if(mysqli_num_rows($query)>0) {
                            while ($row=mysqli_fetch_assoc($query)) {
                                echo '<tr>';
                                $id= $row['teacher_id'];
                                // echo '<td>'.$row['teacher_id'].'</td>';
                                echo '<td>'.$row['teacher_lastname'].'</td>';
                                echo '<td>'.$row['teacher_firstname'].'</td>';
                                echo '<td>'.$row['teacher_middlename'].'</td>';
                                echo '<td>'.$row['teacher_address'].'</td>';
                                echo '<td>'.$row['teacher_contact_number'].'</td>';
                                echo '<td><a href="teacherupdate.php?id='.$id.'" style="text-decoration: none;"><i style="margin-right: 5px;" class="fas fa-edit"></i>UPDATE</a><a href="teacherdelete.php?id='.$id.'" style="text-decoration: none;"><i style="margin-right: 5px;" class="fas fa-user-minus"></i>DELETE</a></td>';
                                echo '</tr>';
                            }
                        }
                        else{
                            echo "No data.";

                        }
                    ?>
                </tbody>

            </table>
            <style type="text/css">
        body{
            background-image: url("school.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100%;
            background-position: center;
            font-family: cursive;
            cursor: pointer;     

        }   
        body:after{
            content: "";
            background: url("logo.png");
            opacity: 1.0;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            position: absolute;
            z-index: -5;
          
        }
        h1{
            margin-top: 130px; 
            font-family: cursive;
            font-size: 50px;
            font-weight: bolder;
            color: #000;
            margin-bottom: 80px;
        }

        ul{
                margin: 0;
                padding: 100px;
                text-align: center;
                list-style-type: none;
                overflow: hidden;
        }

        li{
                float:left;
                font-family: cursive;
        }

        a:link,a:visited{
                display: block;
                font-weight: bold;
                color: #000;
                background-color: #fff;
                width: 150px;
                text-transform: uppercase;
                text-decoration: none;
        }

        li a {
                display: block;
                color: #000;
                text-align: center;
                margin-left: 20px;
                margin-right: 10px;
                padding:10px 5px;
                text-decoration: none;
                font-size: 20px;
                font-weight: bold;
                border-radius: 5px;
        }
        li a:hover:not(.active) {
                background-color:   #5BB9FF;
        }

        li a:hover {
                background-color:   #5BB9FF;
                border-radius: 4px;
        }
        li a.active{
                 background-color:  #5BB9FF;
                 border-radius: 4px;
        }
            </style>
            <ul>
                <center><li><a href="adminhome.php" style="margin-left: 500px; border: 1px solid #000;"><i style="margin-right: 5px;" class="fas fa-backspace"></i>BACK</a></li></center>
        </ul>
        
        <style>
html {
  box-sizing: border-box;

}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.container {
  padding: 0 16px;

}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #2b864b;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

p{
  color: black;
}

h2{
  color: black;
}
</style>
</head>
<body>

<h2 style="text-align: center; color: white;">"Meet The Teachers" </h2>

<br>

<div class="row">
  <div class="column">
    <div class="card">
      <img src="team1.jpg" alt="Jane" style="width:100%">
      <div class="container">
        <h2 style="color: white;">Jane Wyane</h2>
        <p style="color: white;" class="title">Science Teacher</p>
        <p style="color: white;">Home Town: Kentucky</p>
        <p style="color: white;"><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="team2.jpg" alt="Mike" style="width:100%">
      <div class="container">
        <h2 style="color: white;">Drake Isaac</h2>
        <p style="color: white;" class="title">Mathemathics Teacher</p>
        <p style="color: white;">Home Town: California</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img src="team3.jpg" alt="John" style="width:100%">
      <div class="container">
        <h2 style="color: white;">John Hill</h2>
        <p style="color: white;" class="title">English Teacher</p>
        <p style="color: white;">Home Town: Los Angeles</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>





</div>


</body>
</html>