<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
    <title>Parent Details</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" type="text/css" href="css/parentdetails.css">
</head>
           <center><h1 style="color: white;">Parent Details</h1></center>


        <hr>
            <table class="tab3" style="font-family: cursive;">
                <thead>

        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-user"></i>PARENT LASTNAME</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-user"></i>PARENT FIRSTNAME</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-user"></i>PARENT MIDDLENAME</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-address-book"></i>PARENT ADDRESS</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;"><i style="margin-right: 5px;" class="fas fa-phone"></i>CONTACT #</th>
        <th style="color: white; background-color:#2b864b; border: 4px solid #000; padding: 10px 30px 10px 25px;">ACTIONS</th>

                </thead>
                <tbody bgcolor="#C0C0C0" style="text-align: center;">
                    <!-- <button class="logout" type="button"><a href="home.php">Log Out</a></button> -->
                    <?php
                        include('connection.php');

                        $sql = "Select * FROM parents";


                        $query = mysqli_query($db,$sql);
                        if(mysqli_num_rows($query)>0) {
                            while ($row=mysqli_fetch_assoc($query)) {
                                echo '<tr>';
                                $id= $row['parent_id'];
                                echo '<td>'.$row['parent_lastname'].'</td>';
                                echo '<td>'.$row['parent_firstname'].'</td>';
                                echo '<td>'.$row['parent_middlename'].'</td>';
                                echo '<td>'.$row['parent_address'].'</td>';
                                echo '<td>'.$row['parent_contact_number'].'</td>';
                                echo '<td><a href="parentupdate.php?id='.$id.'" style="text-decoration: none;"><i style="margin-right: 5px;" class="fas fa-edit"></i>UPDATE</a><a href="parentdelete.php?id='.$id.'" style="text-decoration: none;"><i style="margin-right: 5px;" class="fas fa-user-minus"></i>DELETE</a></td>';
                                echo '</tr>';


                            }
                        }
                        else{
                            echo "No data.";


                        }

                    ?>


                </tbody>

            </table>
            <style type="text/css">
        body{

            background-image: url("school.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100%;
            background-position: center;
            font-family: cursive;
            cursor: pointer;

        }
        body:after{
            content: "";
            opacity: 1.0;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            position: absolute;
            z-index: -5;

        }
        h1{
            margin-top: 130px;
            font-family: cursive;
            font-size: 50px;
            font-weight: bolder;
            color: #000;
            margin-bottom: 80px;
        }

        ul{
                margin: 0;
                padding: 100px;
                text-align: center;
                list-style-type: none;
                overflow: hidden;
        }

        li{
                float:left;
                font-family: cursive;
        }

        a:link,a:visited{
                display: block;
                font-weight: bold;
                color: #000;
                background-color: #e4dede;
                width: 150px;
                text-transform: uppercase;
                text-decoration: none;
        }

        li a {
                display: block;
                color: #000;
                text-align: center;
                margin-left: 20px;
                margin-right: 10px;
                padding:10px 5px;
                text-decoration: none;
                font-size: 20px;
                font-weight: bold;
                border-radius: 5px;
        }
        li a:hover:not(.active) {
                background-color:   #5BB9FF;
        }

        li a:hover {
                background-color:   #5BB9FF;
                border-radius: 4px;
        }
        li a.active{
                 background-color:  #5BB9FF;
                 border-radius: 4px;
        }
            </style>
        </ul>
            <center><li><a href="adminhome.php" style="margin-left: 600px; border: 1px solid #000;"><i style="margin-right: 5px;" class="fas fa-backspace"></i>BACK</a></li></center>

</body>
</html>
