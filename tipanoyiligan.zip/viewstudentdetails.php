<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
    <title>Student Details</title>
    <link rel="stylesheet" type="text/css" href="css/teacherdetails.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
</head>
            <h1 style="text-align: center; color: white;">Student Details</h1>
            
        <!-- <h2 id="head2">Queen of Angel</h2> -->
        <hr>

            <table class="tab3" style="font-family: cursive;">
                <thead> 
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;"><i style="margin-right: 5px;" class="fas fa-id-card"></i>ID</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;"><i style="margin-right: 5px;" class="fas fa-user"></i>STUDENT LASTNAME</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;"><i style="margin-right: 5px;" class="fas fa-user"></i>STUDENT FIRSTNAME</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;"><i style="margin-right: 5px;" class="fas fa-user"></i>STUDENT MIDDLENAME</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;"><i style="margin-right: 5px;" class="fas fa-level-up-alt"></i>GRADE LEVEL</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;"><i style="margin-right: 5px;" class="fas fa-address-book"></i>STUDENT ADDRESS</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">ACTION</th>

                </thead>
                <tbody bgcolor="#C0C0C0" style="text-align: center;">




            <!-- <table class="tab3" style="font-family: cursive;">
                <thead> 

                    <th bgcolor="b5e7a0">STUDENT ID</th>
                    <th bgcolor="b5e7a0">STUDENT LASTNAME</th>
                    <th bgcolor="b5e7a0">STUDENT FIRSTNAME</th>
                    <th bgcolor="b5e7a0">STUDENT MIDDLENAME</th>
                    <th bgcolor="b5e7a0">GRADE LEVEL</th>
                    <th bgcolor="b5e7a0">STUDENT ADDRESS</th>
                    <th bgcolor="b5e7a0">ACTION</th>
                    
                    

                </thead>
                <tbody bgcolor="b5e7a0" style="text-align: center;">
                     -->
                    <?php
                        include('connection.php');

                        $sql = "Select * FROM student";
                        

                        $query = mysqli_query($db,$sql);
                        if(mysqli_num_rows($query)>0) {
                            while ($row=mysqli_fetch_assoc($query)) {
                                echo '<tr>';
                                $id= $row['student_id'];
                                echo '<td>'.$row['student_id'].'</td>';
                                echo '<td>'.$row['student_lastname'].'</td>';
                                echo '<td>'.$row['student_firstname'].'</td>';
                                echo '<td>'.$row['student_middlename'].'</td>';
                                echo '<td>'.$row['grade_level'].'</td>';
                                echo '<td>'.$row['student_address'].'</td>';
                        

                                echo '<td><a href="input.php?id='.$id.'" style="text-decoration: none;"><i class="fas fa-pencil-alt"></i>INPUT GRADES</a></td>';
                                // echo '</tr>';


                            }
                        }
                        else{
                            echo "No data.";

                        
                        }


         
                    ?>

        
                </tbody>

            </table>
            <style type="text/css">
            body{

            background-image: url("school.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            background-position: center center;
            font-family: cursive;
            cursor: pointer;     

        }   
            
            h1{
                font-family: cursive;
                font-size: 50px;
            }
            h2{
                text-align:center;
                color: white;                 
                font-family: cursive;
                font-size: 50px;
            }   

            ul{
                margin: 0;
                padding: 100px;
                text-align: center;
                list-style-type: none;
                overflow: hidden;
            }

            li{
                float:left;
                font-family: cursive;
            }
            a:link,a:visited{
                display: block;
                font-weight: bold;
                color: black;
                background-color: #C0C0C0;
                width: 150px;
                text-transform: uppercase;
                text-decoration: none;
            }
            </style>
            <ul>
                <center><li><a href="teacherhome.php"><i style="margin-right: 5px;" class="fas fa-backspace"></i>BACK</a></li></center>
        



        </ul>
            

</body>
</html>