<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
    <title>Grades</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    
</head>
            <h1 style="color: white; font-family: cursive; height: 10px; text-align: center;">GRADES</h1>
            
        <!-- <h2 id="head2">Queen of Angel</h2> -->
        <hr>


                <table class="tab3" style="font-family: cursive; margin-left: 6%;">
                <thead> 
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">SCHOOL YEAR</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">1ST GRADING</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">2ND GRADING</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">3RD GRADING</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">4TH GRADING</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">GPA</th>
        <th style="background-color:#2b864b; border: 2px solid #000; padding: 10px 30px 10px 25px; color: white;">STUDENT ID</th>

                </thead>
                <tbody bgcolor="#C0C0C0" style="text-align: center;">


           <!--  <table class="tab3" style="font-family: cursive; ">
                <thead> 

                    <th bgcolor="b5e7a0">SCHOOL YEAR</th>
                  
                    <th bgcolor="b5e7a0">1ST GRADING</th>
                    <th bgcolor="b5e7a0">2ND GRADING</th>
                    <th bgcolor="b5e7a0">3RD GRADING</th>
                    <th bgcolor="b5e7a0">4TH GRADING</th>
                    <th bgcolor="b5e7a0">GPA</th>
                    <th bgcolor="b5e7a0">STUDENT ID</th>
                    

                </thead>
                <tbody bgcolor="b5e7a0" style="text-align: center;"> -->
                    <!-- <button class="logout" type="button"><a href="home.php">Log Out</a></button> -->
                    <?php
                        include('connection.php');

                        $sql = "Select * FROM grade_info";
                        

                        $query = mysqli_query($db,$sql);
                        if(mysqli_num_rows($query)>0) {
                            while ($row=mysqli_fetch_assoc($query)) {
                                echo '<tr>';
                                $id= $row['grade_id'];
                                echo '<td>'.$row['school_year'].'</td>';
                                
                                
                                echo '<td>'.$row['first_grading'].'</td>';
                                echo '<td>'.$row['second_grading'].'</td>';
                                echo '<td>'.$row['third_grading'].'</td>';
                                echo '<td>'.$row['fourth_grading'].'</td>';
                                echo '<td>'.$row['grade_gpa'].'</td>';
                                echo '<td>'.$row['student_id'].'</td>';
                                echo '</tr>';

                            }

                        }
         
                    ?>

        
                </tbody>

            </table>
            <style type="text/css">

            body{
            background-image: url("school.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            background-position: center center;
            font-family: cursive;
            cursor: pointer;     
        }   
            h1{
                font-family: cursive;
                font-size: 50px;
                margin-bottom: 10%;
             }
            h2{
                text-align:center;
                color: white;                 
                font-family: cursive;
                font-size: 50px;
            }   

            ul{
                margin: 0;
                padding: 100px;
                text-align: center;
                list-style-type: none;
                overflow: hidden;
            }

            li{
                float:left;
                font-family: cursive;
            }
            a:link,a:visited{
                display: block;
                font-weight: bold;
                color: black;
                background-color: #b5e7a0;
                width: 150px;
                text-transform: uppercase;
                text-decoration: none;
            }

             li a:hover:not(.active) {
                background-color:   #5BB9FF;
        }

        li a:hover {
                background-color:   #5BB9FF;
                border-radius: 4px;
        }
        li a.active{
                 background-color:  #5BB9FF;
                 border-radius: 4px;
        }

            
                   }

            </style>
            <ul>
                <center><li><a href="studenthome.php" style="margin-left: 350px; border: 1px solid #000;"><i style="margin-right: 5px;" class="fas fa-backspace"></i>BACK</a></li></center>
        



        </ul>
            

</body>
</html>



