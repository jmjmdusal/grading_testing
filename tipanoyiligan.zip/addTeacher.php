<?php

include('connection.php');

if(isset($_POST['add'])){

$teacher_lastname = $_POST['teacher_lastname'];
$teacher_firstname = $_POST['teacher_firstname'];
$teacher_middlename = $_POST['teacher_middlename'];
$teacher_address = $_POST['teacher_address'];
$teacher_contact_number = $_POST['teacher_contact_number'];
$teacher_username = $_POST['teacher_username'];
$teacher_password = $_POST['teacher_password'];
$teacher_confirm_password = $_POST['teacher_confirm_password'];



$sql = "INSERT INTO teacher(teacher_lastname, teacher_firstname, teacher_middlename, teacher_address, teacher_contact_number, teacher_username, teacher_password, teacher_confirm_password) VALUES('$teacher_lastname','$teacher_firstname','$teacher_middlename','$teacher_address','$teacher_contact_number','$teacher_username','$teacher_password','$teacher_confirm_password')";

$result = mysqli_query($db, $sql);

if($result){
    header('location: adminhome.php');

}
    
    
}

 ?>









 <!DOCTYPE html>
 <html>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <head>
    <title>Add Teacher</title>
    <style>
    
    body{
      background-image: url("school.jpg");
          background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
          background-position: center center;
            font-family: cursive;
            cursor: pointer;     

    } 
    body:after{
      content: "";
      
      opacity: 1.0;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      position: absolute;
      z-index: -5;
      
    }


    form{
    width: 30%;
    margin: 0px auto;
    font-size: 15px;
    font-weight: bold;
    padding: 20px;
    border: 1px solid #000;
    background: white;
    border-radius: 0px 0px 10px 10px;
}

.input-group{
    margin: 10px 0px 10px 0px;
}
.input-group label{
    display: block;
    text-align: left;
    margin: 3px;
}
.input-group input{
    height: 30px;
    width: 93%;
    padding: 5px 10px;
    font-size: 16px;
    border-radius: 6px;
    border: 2px solid gray;
}
.btn{
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #3bd478;
    border: none;
    border-radius: 5px;
}

.header {
    width: 30%;
    margin: 50px auto 0px;
    color: white;
    background: url('cover1.jpg');
    /*background: #6174ff;*/
    text-align: center;
    border: 1px solid #000;
    border-bottom: none;
    border-radius: 10px 10px 0px 0px;
    padding: 20px;

}
.header a{
    text-decoration: none;
    color: black;
    font-family: cursive;
}

  </style>
 </head>
 <body>
    <div class="header">
            <h2>Add Teacher</h2>
    </div>

 
<form method="POST" style="text-align: center; font-family: cursive;">

<div class="input-group">
<label>TEACHER LASTNAME</label>
<input type="text" name="teacher_lastname" placeholder="Last Name"><br></br>
</div>

<div class="input-group">
<label>TEACHER FIRSTNAME</label>
<input type="text" name="teacher_firstname" placeholder="First Name"><br></br>
</div>

<div class="input-group">
<label>TEACHER MIDDLENAME</label>
<input type="text" name="teacher_middlename" placeholder="Middle Name"><br></br>
</div>

<div class="input-group">
<label>TEACHER ADDRESS</label>
<input type="text" name="teacher_address" placeholder="Address"><br></br>
</div>

<div class="input-group">
<label>TEACHER CONTACT #</label>
<input type="number" name="teacher_contact_number" placeholder="Contact"><br></br>
</div>

<div class="input-group">
<label>TEACHER USERNAME</label>
<input type="text" name="teacher_username" placeholder="Username"><br></br>
</div>

<div class="input-group">
<label>TEACHER PASSWORD</label>
<input type="password" name="teacher_password" placeholder="Password"><br></br>
</div>

<div class="input-group">
<label>CONFIRM PASSWORD</label>
<input type="password" name="teacher_confirm_password" placeholder="Confirm Password"><br></br>
</div>

<input type="submit" name="add">
<a href="adminhome.php" style="text-decoration: none; text-align: center;">Back</a>
</form>
    

    
 </body>
 </html>