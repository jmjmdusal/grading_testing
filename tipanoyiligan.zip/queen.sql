-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2019 at 04:05 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `queen`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_lastname` varchar(25) DEFAULT NULL,
  `admin_firstname` varchar(25) DEFAULT NULL,
  `admin_middlename` varchar(25) DEFAULT NULL,
  `admin_username` varchar(25) DEFAULT NULL,
  `admin_password` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_lastname`, `admin_firstname`, `admin_middlename`, `admin_username`, `admin_password`) VALUES
(1, 'Dusal', 'John Michael', 'Romalig', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `grade_info`
--

CREATE TABLE `grade_info` (
  `grade_id` int(11) NOT NULL,
  `school_year` varchar(10) NOT NULL,
  `first_grading` varchar(25) NOT NULL,
  `second_grading` varchar(25) DEFAULT NULL,
  `third_grading` varchar(25) DEFAULT NULL,
  `fourth_grading` varchar(25) DEFAULT NULL,
  `grade_gpa` double NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grade_info`
--

INSERT INTO `grade_info` (`grade_id`, `school_year`, `first_grading`, `second_grading`, `third_grading`, `fourth_grading`, `grade_gpa`, `student_id`) VALUES
(13, '2018', '85', '91', '86', '81', 85.75, 1),
(14, '2019', '71', '75', '73', '74', 73.25, 2),
(15, '2012', '85', '73', '75', '81', 78.5, 1),
(16, '2018', '80', '80', '80', '80', 80, 1),
(17, '2019', '98', '96', '78', '75', 86.75, 2),
(18, '2018', '78', '81', '83', '86', 82, 1),
(19, '2015', '71', '75', '78', '77', 75.25, 1),
(20, '2066', '65', '56', '65', '56', 60.5, 3),
(21, '2017', '80', '75', '75', '80', 77.5, 5),
(22, '2018', '85', '89', '86', '79', 84.75, 5),
(23, '0', '96', '90', '91', '95', 93, 5),
(24, '2001', '90', '90', '90', '90', 90, 1),
(25, '2018', '90', '89', '89', '88', 89, 2),
(26, '0', '96', '95', '93', '91', 93.75, 1),
(27, '0', '90', '92', '95', '86', 90.75, 1),
(28, '0', '89', '89', '89', '90', 89.25, 1),
(29, '2019', '85', '85', '86', '90', 86.5, 1),
(30, '2001', '95', '95', '96', '89', 93.75, 1),
(31, '2015', '95', '96', '90', '86', 91.75, 9),
(32, '0', '95', '96', '94', '94', 94.75, 10),
(33, '2015', '81', '81', '81', '81', 81, 10),
(34, '2019', '78', '85', '81', '80', 81, 1),
(35, '-1', '75', '75', '78', '76', 76, 1),
(36, '2020', '86', '85', '85', '89', 86.25, 10),
(37, '2018', '95', '98', '96', '93', 95.5, 1),
(38, '2018', '80', '86', '83', '81', 82.5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `parent_id` int(11) NOT NULL,
  `parent_lastname` varchar(25) DEFAULT NULL,
  `parent_firstname` varchar(25) DEFAULT NULL,
  `parent_middlename` varchar(25) DEFAULT NULL,
  `parent_address` varchar(25) DEFAULT NULL,
  `parent_contact_number` varchar(25) DEFAULT NULL,
  `parent_username` varchar(25) DEFAULT NULL,
  `parent_password` varchar(25) DEFAULT NULL,
  `parent_confirm_password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`parent_id`, `parent_lastname`, `parent_firstname`, `parent_middlename`, `parent_address`, `parent_contact_number`, `parent_username`, `parent_password`, `parent_confirm_password`) VALUES
(12, 'grabi kaaa da', 'Zeusz', 'Hucks', 'Zimple', '0955987456', 'parent1', 'parent1', 'parent1'),
(13, 'Pia', 'Roselle', 'DODODO', 'Tibanga', '09994105487', 'parent2', 'parent2', 'parent2'),
(14, 'Guko', 'San', 'Gorilla', 'Dragonz', '09556487154', 'parent3', 'parent3', 'parent3'),
(15, 'Flexinja', 'Vortex', 'Macho', 'Singapore', '09883561690', 'parent4', 'parent4', 'parent4'),
(16, 'Helix', 'Lokoko', 'Lix', 'Tubod', '09168945810', 'parent5', 'parent5', 'parent5'),
(17, 'Goshen', 'Alicia', 'Jackson', 'Baraas', '09369814589', 'parent6', 'parent6', 'parent6'),
(18, 'parentli', 'parentli', 'psssss', 'palao', '09555555', 'parentli', 'parentli', ''),
(19, 'momo', 'momo', 'momo', 'momo', '555', 'momo', 'momo', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_lastname` varchar(25) DEFAULT NULL,
  `student_firstname` varchar(25) DEFAULT NULL,
  `student_middlename` varchar(25) DEFAULT NULL,
  `grade_level` varchar(25) DEFAULT NULL,
  `student_address` varchar(25) DEFAULT NULL,
  `student_username` varchar(25) DEFAULT NULL,
  `student_password` varchar(25) DEFAULT NULL,
  `student_confirm_password` varchar(25) NOT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_lastname`, `student_firstname`, `student_middlename`, `grade_level`, `student_address`, `student_username`, `student_password`, `student_confirm_password`, `parent_id`) VALUES
(1, 'jonaxssss', 'Donna', 'sssssss', '6', 'Sorsogon', 'student1', 'student1', 'student1', 12),
(2, 'Switzer', 'Isaac', 'Levi', '5', 'Sorsogon', 'student2', 'student2', '', 13),
(3, 'Scott', 'Hillary', 'Harden', '4', 'Cebu', 'student3', 'student3', '', 14),
(4, 'lllll', 'lllll', 'lllll', '6', 'llll', NULL, NULL, '', NULL),
(5, 'wala', 'wala', 'wala', '5', 'walawala', NULL, NULL, '', NULL),
(6, 'siroks', 'siroks', 'siroks', '5', 'siroks', 'sirok', 'sirok', '', NULL),
(7, 'walako', 'walako', 'walako', '4', 'walakolagi', NULL, NULL, '', NULL),
(8, 'asia', 'asia', 'asia', '3', 'asia', 'asia', 'asia', '%student_confirm_password', NULL),
(9, 'lol', 'lol', 'lol', '5', 'lol', 'lol', 'lol', '%student_confirm_password', NULL),
(10, 'qwe', 'qwe', 'qwe', '7', 'qwe', 'qwe', 'qwe', '%student_confirm_password', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `student_subject_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subjects_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subjects_id` int(11) NOT NULL,
  `subject_name` varchar(25) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `teacher_lastname` varchar(25) DEFAULT NULL,
  `teacher_firstname` varchar(25) DEFAULT NULL,
  `teacher_middlename` varchar(25) DEFAULT NULL,
  `teacher_address` varchar(25) DEFAULT NULL,
  `teacher_contact_number` varchar(30) DEFAULT NULL,
  `teacher_username` varchar(25) DEFAULT NULL,
  `teacher_password` varchar(25) DEFAULT NULL,
  `teacher_confirm_password` varchar(25) NOT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `teacher_lastname`, `teacher_firstname`, `teacher_middlename`, `teacher_address`, `teacher_contact_number`, `teacher_username`, `teacher_password`, `teacher_confirm_password`, `admin_id`) VALUES
(3, 'sabafwanzzzz', 'Ralph', 'O', 'Mandaluyong MNL', '09649215920', 'teacher2', 'teacher2', 'teacher2', NULL),
(4, 'Zuckerberg', 'Mark', 'U', 'Palo Alto CA', '09978659881', 'teacher1', 'teacher1', '', NULL),
(5, 'Brooks', 'Naj', 'G', 'Burg ITALY', '09578633610', 'asd', 'asd', '', NULL),
(8, 'Doe', 'Jane', 'D', 'IC', '65456', 'jane', '123456', '', NULL),
(11, 'Dusaljmmm', 'Michael', 'R', 'Pala-o IC', '09559133309', 'teacherdusal', 'teacherdusal', 'teacherdusal', NULL),
(12, 'testasd', 'testasd', 'testasd', 'testasd', '00002555', 'testasd', 'testasd', 'testasd', NULL),
(13, 'zzzzzzzz', 'zzzzzzzzz', 'zzzzzz', 'zzzzzzz', '1111111', 'zzz', 'zzz', 'zzz', NULL),
(14, 'ambot', 'ambot', 'ambot', 'ambotssss', '123', 'ambot', 'ambot', 'ambot', NULL),
(15, 'gara', 'gara', 'gara', 'gara', '123123', 'gara', 'gara', 'gara', NULL),
(16, 'samplessss', 'samplessss', 'samplesss', 'sample', '2222', 'sample', 'sample', 'sample', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `grade_info`
--
ALTER TABLE `grade_info`
  ADD PRIMARY KEY (`grade_id`),
  ADD KEY `student` (`student_id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`parent_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`student_subject_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subjects_id` (`subjects_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subjects_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `grade_info`
--
ALTER TABLE `grade_info`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `parent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `student_subject_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subjects_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `grade_info`
--
ALTER TABLE `grade_info`
  ADD CONSTRAINT `student` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`parent_id`);

--
-- Constraints for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD CONSTRAINT `student_subject_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`),
  ADD CONSTRAINT `student_subject_ibfk_2` FOREIGN KEY (`subjects_id`) REFERENCES `subjects` (`subjects_id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`);

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
