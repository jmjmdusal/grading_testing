<?php

include('connection.php');

$student_id = $_GET['id'];

if(isset($_POST['input'])){

$school_year = $_POST['school_year'];
$first_grading = $_POST['first_grading'];
$second_grading = $_POST['second_grading'];
$third_grading = $_POST['third_grading'];
$fourth_grading = $_POST['fourth_grading'];
$grade_gpa = ($first_grading + $second_grading + $third_grading + $fourth_grading)/4;



$sql = "INSERT INTO grade_info(school_year,first_grading, second_grading, third_grading, fourth_grading, grade_gpa, student_id) VALUES($school_year,$first_grading,$second_grading,$third_grading,$fourth_grading,$grade_gpa, $student_id)";

$query = mysqli_query($db, $sql);
if($query){
	header('location:viewGrades.php');
}

// $sql2 = "INSERT INTO subjects(subject_name,teacher_id) values ('$subject_name',1)";

// $sql3 = "SELECT * from grade_info as g INNER JOIN student as s on g.student_id=s.student_id where  g.grade_id=".$_SESSION["grade_id"];
// $query = mysqli_query($db,$sql3);
	}

 ?>

<!DOCTYPE html>
 <html>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <head>
 	<title>Input Grades</title>

 </head>
 <body>
 	<div class="header">
 			<h2>Input Grades</h2></a>
 	</div>

 <form method="POST" action="#">

    <div class="input-group">
 		<label>SCHOOL YEAR</label>
 		<input type="number" name="school_year">
 	</div>

 	<div class="input-group">
 		<label>1ST GRADING</label>
 		<input type="number" name="first_grading">
 	</div>

 	<div class="input-group">
 		<label>2ND GRADING</label>
 		<input type="number" name="second_grading">
 	</div>

 	<div class="input-group">
 		<label>3RD GRADING</label>
 		<input type="number" name="third_grading">
 	</div>
 	<div class="input-group">
 		<label>4TH GRADING</label>
 		<input type="number" name="fourth_grading">
 	</div>

 	<button type="submit" name="input" class="btn">Submit</button>
	<a href="viewstudentdetails.php" style="text-decoration: none; background-color: #2b864b;"><button type="button">Back</a>

 </form>
 	<style>
 		* {
	margin: 0px;
	padding: 0px;
}
body {
	font-size: 90%;
	background-image: url("school.jpg");
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-size: cover;
	background-position: center center;
	font-family: cursive;
	cursor: pointer;

}
.header {
	width: 30%;
	margin: 50px auto 0px;
	color: white;
	background: #2b864b;
	text-align: center;
	border: 1px solid #000;
	border-bottom: none;
	border-radius: 10px 10px 0px 0px;
	padding: 20px;
}
.header a{
	text-decoration: none;
	color: #fff;
}
form{
	width: 30%;
	margin: 0px auto;
	font-size: 15px;
	font-weight: bold;
	padding: 20px;
	border: 1px solid #000;
	background-color:  #9c9cab;
	border-radius: 0px 0px 10px 10px;
}

.input-group{
	margin: 10px 0px 10px 0px;
}
.input-group label{
	display: block;
	text-align: left;
	margin: 3px;
}
.input-group input{
	height: 30px;
	width: 93%;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 5px;
	border: 1px solid gray;
}
.btn{
	padding: 10px;
	font-size: 15px;
	color: white;
	background: #2b864b;
	border: none;
	border-radius: 5px;

}


 	</style>

 </body>
 </html>
