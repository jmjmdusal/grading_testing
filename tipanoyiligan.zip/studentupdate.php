<?php
  include('connection.php');

  $studentID= $_GET['id'];

  //echo $studentID;
  if (isset($_POST['save'])){
    $student_lastname = $_POST['student_lastname'];
    $student_firstname = $_POST['student_firstname'];
    $student_middlename = $_POST['student_middlename'];
    $grade_level = $_POST['grade_level'];
    $student_address = $_POST['student_address'];
    $student_username = $_POST['student_username'];
    $student_password = $_POST['student_password'];
    
    
    


    $sql2 = "UPDATE student SET student_lastname='$student_lastname', student_firstname='$student_firstname', student_middlename='$student_middlename', grade_level='$grade_level', student_address='$student_address', student_username='$student_username', student_password='$student_password' WHERE student_id = $studentID";



    $sql2 = mysqli_query($db,$sql2);
    header("Location:studentdetails.php");


  }
  else{
    echo "<script>alert('Are you sure you want to update this data??')</script>";
      
      
  }
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
<title> Edit </title>

</head>
<body>
  <div class="header">
            <h2>Edit Student</h2>
    </div>
  <style>
    
    body{
      background-image: url("school.jpg");
          background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
          background-position: center center;
            font-family: cursive;
            cursor: pointer;     

    } 
    body:after{
      content: "";
      background: url("cover1.jpg");
      opacity: 1.0;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      position: absolute;
      z-index: -5;
      
    }

    form{
    width: 30%;
    margin: 0px auto;
    font-size: 15px;
    font-weight: bold;
    padding: 20px;
    border: 1px solid #000;
    background: white;
    border-radius: 0px 0px 10px 10px;
}

.input-group{
    margin: 10px 0px 10px 0px;
}
.input-group label{
    display: block;
    text-align: left;
    margin: 3px;
}
.input-group input{
    height: 30px;
    width: 93%;
    padding: 5px 10px;
    font-size: 16px;
    border-radius: 6px;
    border: 2px solid gray;
}
.btn{
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #3bd478;
    border: none;
    border-radius: 5px;
}

.header {
    width: 30%;
    margin: 50px auto 0px;
    color: white;
    background: url('images/cover1.jpg');
    /*background: #6174ff;*/
    text-align: center;
    border: 1px solid #000;
    border-bottom: none;
    border-radius: 10px 10px 0px 0px;
    padding: 20px;

}
.header a{
    text-decoration: none;
    color: black;
    font-family: cursive;
}

  </style>


  <?php
    $sql = "SELECT * FROM student WHERE student_id = $studentID";
    
    $query = mysqli_query($db,$sql);
    $data = mysqli_fetch_assoc($query);
  

    
?>



<form action="#" method="post" style="text-align: center; font-family: cursive;">

<div class="input-group">
<label>LASTNAME</label>
<input type="text" name="student_lastname" value="<?php echo $data['student_lastname']; ?>" ><br></br>
</div>

<div class="input-group">
<label>FIRSTNAME</label>
<input type="text" name="student_firstname" value="<?php echo $data['student_firstname']; ?>" ><br></br>
</div>

<div class="input-group">
<label>MIDDLENAME</label>
<input type="text" name="student_middlename" value="<?php echo $data['student_middlename']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>GRADE LEVEL</label>
<input type="number" name="grade_level" value="<?php echo $data['grade_level']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>ADDRESS</label>
<input type="text" name="student_address" value="<?php echo $data['student_address']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>USERNAME</label>
<input type="text" name="student_username" value="<?php echo $data['student_username']; ?>" ><br/><br/>
</div>

<div class="input-group">
<label>PASSWORD</label>
<input type="text" name="student_password" value="<?php echo $data['student_password']; ?>" ><br/><br/>
</div>

<input type="submit" name="save" value="Submit"/>
<a href="studentdetails.php" style="text-decoration: none; font-family: cursive;"><button type="button">Back</a></td></td>


 

</form>
</body>
</html>
