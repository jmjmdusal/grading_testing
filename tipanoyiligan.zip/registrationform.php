<?php

		include('connection.php');
		if (isset($_POST['registrationform'])) {
		$parent_lastname = $_POST['parent_lastname'];
		$parent_firstname = $_POST['parent_firstname'];
		$parent_middlename = $_POST['parent_middlename'];
		$parent_address = $_POST['parent_address'];
		$parent_contact_number = $_POST['contact_number'];
		$parent_username = $_POST['parent_username'];
		$parent_password1 = $_POST['parent_password_1'];
		$parent_password2 = $_POST['parent_password_2'];


		if ($parent_password1 != $parent_password2) {
			echo "Error Password";
		}



		else{
					$sql = "INSERT INTO parents (parent_lastname, parent_firstname, parent_middlename, parent_address, parent_contact_number, parent_username, parent_password) VALUES ('$parent_lastname','$parent_firstname','$parent_middlename','$parent_address','$parent_contact_number','$parent_username','$parent_password1')";

			$query = mysqli_query($db, $sql);


			$sql1 = "SELECT max(parent_id) as parent_id from parents";
				$query2 = mysqli_query($db,$sql1);
			$row = mysqli_fetch_assoc($query2);



			$parent_id = $row['parent_id'];


				if ($query2) {
					echo "<script>alert('Successfully Registered!')</script>";
					 $_SESSION['parent_username'] = $parent_username;
					// $_SESSION['Success'] = "You are now logged in";
					header('location: registrationform.php');
				}

		}
}

/*mysqli_query($con,$query);
if($query2){
	echo "<script>alert('You have succesfully Registered!')</script>";
	header('Location:sample.php');
}
	else{
		echo "<script>alert('Oops naay sayop')</script>";
	}*/
?>


<!DOCTYPE html>
 <html>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <head>

 	<title>Registration Form</title>
 	
 </head>
 <body>
 	<div class="header">
 			<h2>Registration Form</h2>
 	</div>

 <form method="post" action="registrationform.php">
 	<!-- <select name = "nameSaAttribute">

  <option value="parents">Parent</option>

  <option value="student">Student</option>

</select> -->

 	<div class="input-group">
 		<label>Last Name</label>
 		<input type="text" name="parent_lastname" placeholder="Last Name">
 	</div>

 	<div class="input-group">
 		<label>First Name</label>
 		<input type="text" name="parent_firstname" placeholder="First Name">
 	</div>
 	<div class="input-group">
 		<label>Middle Name</label>
 		<input type="text" name="parent_middlename" placeholder="Middle Name">
 	</div>
 		<div class="input-group">
 		<label>Address</label>
 		<input type="text" name="parent_address" placeholder="Address">
 	</div
 	><div class="input-group">
 		<label>Contact Number</label>
 		<input type="number" name="contact_number" placeholder="Contact Number">
 	</div>
 	<div class="input-group">
 		<label>Username</label>
 		<input type="text" name="parent_username" placeholder="Username">
 	</div>
 	<div class="input-group">
 		<label>Password</label>
 		<input type="password" name="parent_password_1" placeholder="Password">
 	</div>
 	<div class="input-group">
 		<label>Confirm Password</label>
 		<input type="password" name="parent_password_2"placeholder="Confirm Password">
 	</div>
 	<div class="input-group">
 		<button type="submit" name="registrationform" class="btn">Register</button>
 	</div>
 	<p>
 		Already a member? <a href="login.php" style = "text-decoration: none;">Sign in</a>
 	</p>


	<a href="login.php" style="text-decoration: none;"><button type="button">Back</a>

 </form>
 	<style>
 		* {
	margin: 0px;
	padding: 0px;
}
body {
	background-image: url("school.jpg");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: 100%;
    background-position: center;
    font-family: cursive;
    cursor: pointer;


}
.header {
	width: 30%;
	margin: 50px auto 0px;
	color: white;
	background: url('cover1.jpg');
	/*background: #6174ff;*/
	text-align: center;
	border: 1px solid #000;
	border-bottom: none;
	border-radius: 10px 10px 0px 0px;
	padding: 20px;

}
.header a{
	text-decoration: none;
	color: black;
	font-family: cursive;
}
form{
	width: 30%;
	margin: 0px auto;
	font-size: 15px;
	font-weight: bold;
	padding: 20px;
	border: 1px solid #000;
	background: white;
	border-radius: 0px 0px 10px 10px;
}

.input-group{
	margin: 10px 0px 10px 0px;
}
.input-group label{
	display: block;
	text-align: left;
	margin: 3px;
}
.input-group input{
	height: 30px;
	width: 93%;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 6px;
	border: 2px solid gray;
}
.btn{
	padding: 10px;
	font-size: 15px;
	color: white;
	background: #3bd478;
	border: none;
	border-radius: 5px;
}


 	</style>

 </body>
 </html>
