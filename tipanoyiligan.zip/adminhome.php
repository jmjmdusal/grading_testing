<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
	
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
	<style type="text/css">
	
		body{
			background-image: url("school.jpg");
         	background-repeat: no-repeat;
          	background-attachment: fixed;
          	background-size: cover;
         	background-position: center center;
          	font-family: cursive;
          	cursor: pointer;     

		}	
		body:after{
			content: "";
			
			opacity: 1.0;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
			position: absolute;
			z-index: -5;
			
		}

		h1{
			text-align:center;
   			color: white;                 
   			font-family: cursive;
   			font-size: 50px;
   			margin-top: 120px;
		}

		a:link,a:visited{
			display: block;
			font-weight: bold;
			color: white;
			width: 200px;
			text-transform: uppercase;
			text-decoration: none;
		}
		ul {
		    list-style-type: none;
		    margin-top: 60px;
		    margin-left: 60px;
		    margin-right: 60px; 
		    padding: 5px 5px;
		    overflow: hidden;
		    background-color: #2b864b;
		    top: 0;
		    border-radius: 10px;
		}

		li {
		    float: left;
		}

		li a {
		    display: block;
		    color: #000;
		    text-align: center;
		   	margin-left: 20px;
		   	margin-right: 10px;
		   	padding:10px 5px;
		   	text-decoration: none;
		    font-size: 20px;
		    font-weight: bold;
		}
		li a:hover:not(.active) {
		    background-color: 	#0d54f5;
		}

		li a:hover {
		    background-color:	#0d54f5;
		   	border-radius: 4px;
		}
		li a.active{
			 background-color: 	#0d54f5;
			 border-radius: 4px;
		}


	</style>
</head>
<body>
		<h1> Tipanoy Elementary School</h1>

		<p style="text-align: center;font-size: 30px; font-weight: bolder;background-color:#2b864b;padding: 5px 5px; margin-left: 500px; margin-right: 500px;border-radius: 15px;margin-top:90px; color:white; "><i style="margin-right: 5px;" class="fas fa-user-secret"></i>ADMIN</p>
		<nav>
			<ul>
				<li><a href="parentdetails.php"><i style="margin-right: 5px;" class="fas fa-users"></i>PARENTS DETAIL</a></li>
				<li><a href="teacherdetails.php"><i style="margin-right: 5px;" class="fas fa-user-tie"></i>TEACHERS DETAIL</a></li>
				<li><a href="studentdetails.php"><i style="margin-right: 5px;" class="fas fa-users"></i>STUDENTS DETAIL</a></li>
				<li><a href="viewGrades4.php"><i style="margin-right: 5px;" class="fas fa-pencil-alt"></i>STUDENTS GRADE</a></li>
				<li><a href="addTeacher.php"><i style="margin-right: 5px;" class="fas fa-user-plus"></i>ADD TEACHER</a></li>
				<li><a href="addStudent.php"><i style="margin-right: 5px;" class="fas fa-user-plus"></i>ADD STUDENT</a></li>
				
				<li><a href="index.php"><i style="margin-right: 5px;" class="fas fa-sign-out-alt"></i>LOGOUT</a></li>
		
			</ul>
		</nav>

</body>
</html>