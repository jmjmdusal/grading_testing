<?php

include('connection.php');

if(isset($_POST['add'])){

$student_lastname = $_POST['student_lastname'];
$student_firstname = $_POST['student_firstname'];
$student_middlename = $_POST['student_middlename'];
$grade_level = $_POST['grade_level'];
$student_address = $_POST['student_address'];
$student_username = $_POST['student_username'];
$student_password = $_POST['student_password'];
$student_confirm_password = $_POST['student_confirm_password'];



$sql = "INSERT INTO student(student_lastname, student_firstname, student_middlename, grade_level, student_address, student_username, student_password, student_confirm_password) VALUES('$student_lastname','$student_firstname','$student_middlename','$grade_level','$student_address','$student_username','$student_password','%student_confirm_password')";

$result = mysqli_query($db, $sql);

if($result){
	header('location: adminhome.php');

}
	
	
}

 ?>






 <!DOCTYPE html>
 <html>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <head>
 	<title>Add Student</title>
 	<style>
    
    body{
      background-image: url("school.jpg");
          background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
          background-position: center center;
            font-family: cursive;
            cursor: pointer;     

    } 
    body:after{
      content: "";
      opacity: 1.0;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      position: absolute;
      z-index: -5;
      
    }


    form{
    width: 30%;
    margin: 0px auto;
    font-size: 15px;
    font-weight: bold;
    padding: 20px;
    border: 1px solid #000;
    background: white;
    border-radius: 0px 0px 10px 10px;
}

.input-group{
    margin: 10px 0px 10px 0px;
}
.input-group label{
    display: block;
    text-align: left;
    margin: 3px;
}
.input-group input{
    height: 30px;
    width: 93%;
    padding: 5px 10px;
    font-size: 16px;
    border-radius: 6px;
    border: 2px solid gray;
}
.btn{
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #3bd478;
    border: none;
    border-radius: 5px;
}

.header {
    width: 30%;
    margin: 50px auto 0px;
    color: white;
    background: url('cover1.jpg');
    /*background: #6174ff;*/
    text-align: center;
    border: 1px solid #000;
    border-bottom: none;
    border-radius: 10px 10px 0px 0px;
    padding: 20px;

}
.header a{
    text-decoration: none;
    color: black;
    font-family: cursive;
}

  </style>
 </head>
 <body>
 	<div class="header">
            <h2>Add Student</h2>
    </div>
 
<form method="POST" style="text-align: center; font-family: cursive;">

<div class="input-group">
<label>STUDENT LASTNAME</label>
<input type="text" name="student_lastname" placeholder="Last Name"><br></br>
</div>

<div class="input-group">
<label>STUDENT FIRSTNAME</label>
<input type="text" name="student_firstname" placeholder="First Name"><br></br>
</div>

<div class="input-group">
<label>STUDENT MIDDLENAME</label>
<input type="text" name="student_middlename" placeholder="Middle Name"><br></br>
</div>

<div class="input-group">
<label>GRADE LEVEL</label>
<input type="number" name="grade_level" placeholder="Grade Level"><br></br>
</div>

<div class="input-group">
<label>STUDENT ADDRESS</label>
<input type="text" name="student_address" placeholder="Address"><br></br>
</div>

<div class="input-group">
<label>STUDENT USERNAME</label>
<input type="text" name="student_username" placeholder="Username"><br></br>
</div>

<div class="input-group">
<label>STUDENT PASSWORD</label>
<input type="password" name="student_password" placeholder="Password"><br></br>
</div>

<div class="input-group">
<label>CONFIRM PASSWORD</label>
<input type="password" name="student_confirm_password" placeholder="Confirm Password"><br></br>
</div>



	

<input type="submit" name="add">
<a href="adminhome.php" style="text-decoration: none; text-align: center;">Back</a>
</form>
	
 </body>
 </html>